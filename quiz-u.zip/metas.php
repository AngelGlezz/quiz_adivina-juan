<?php
	$metas = array(
		"mal" => array(
			"title" => "Adivina Juan",
			"description" => "Estás tan lamentable que ni Osorio te quiere en la Selección. Mejor pide disculpas y retírate…",
			"image" => "images/resultado/1.jpg" 
		),
		"maso" => array(
			"title" => "Adivina Juan",
			"description" => "Pues ahí se va… no sacaste un resultado así que tú digas \"uy qué bruto, cuánto sabe\", pero peor es nada",
			"image" => "images/resultado/2.jpg" 
		),
		"bien" => array(
			"title" => "Adivina Juan",
			"description" => "¡Eres como el Superman que todos esperábamos! Si puedes pásame tus datos, te necesito (junto con tus conocimientos) para ganarme una lana",
			"image" => "images/resultado/3.jpg" 
		)
	);